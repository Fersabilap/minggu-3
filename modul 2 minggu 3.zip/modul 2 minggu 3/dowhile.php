<?php
$i  = 1;
do 
{
echo "$i";
$i+=2;
 
}while ($i <= 20);
?>