<?php
$user = "alfandy";
$pass = "12345"
if ($user == "alfandy" && $pass == "12345") {
	echo "Login Berhasil";
} else {
	echo "Login Gagal";
}
?>